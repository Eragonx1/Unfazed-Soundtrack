import React from 'react';
import { Container } from 'react-bootstrap';
import MainLogo from '../../Img/Logo.png';
import "./Login.css";

const AUTH_URL = "https://accounts.spotify.com/authorize?client_id=d854a8b6e1754b23b1446366221d5165&response_type=code&redirect_uri=http://localhost:3000&scope=streaming%20user-read-email%20user-read-private%20user-library-read%20user-library-modify%20user-read-playback-state%20user-modify-playback-state"

export default function Login(){
    return(
        <Container className="d-flex justify-content-center align-items-center"style={{minHeight: "100vh"}}>
            <div className="LogoM">
                <img className="LogoPrincipale" src={MainLogo} alt="Unfazed-Soundtrack" />
            </div>
            <div className="accueil">
                <h1 className="titrePrincipale">"Experience music like never before with Unfazed-SoundTrack - Where rythm meets soul and melodies come to life."</h1>
                <a className="MainButton" href={AUTH_URL}>GET Unfazed-Sountract !!!</a>
            </div>
        </Container>
    )
}