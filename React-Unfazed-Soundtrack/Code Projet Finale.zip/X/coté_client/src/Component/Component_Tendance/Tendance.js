import React from "react";

export default function Tendance({ topTracks , chooseTrack}) {

  function handlePlay() {
      chooseTrack(topTracks)
  }

  return (
    <div className="playlist-item" onClick={handlePlay}>
      <img className="playlist-item__image" src={topTracks.albumUrl} alt="Error" />
      <div className="playlist-item__details">
        <div className="playlist-item__title">{topTracks.title}</div>
        <div className="playlist-item__artist">{topTracks.artist}</div>
      </div>
    </div>
  );
}
