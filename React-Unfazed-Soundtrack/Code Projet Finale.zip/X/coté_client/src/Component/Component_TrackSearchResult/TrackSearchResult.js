import React from "react"
import "./TrackSearchResult.css";

export default function TrackSearchResult({ track, chooseTrack }) {
  
  function handlePlay() {
    chooseTrack(track)
  }

  return (
  <div className="playlist-item" onClick={handlePlay}>
    <img className="playlist-item__image" src={track.albumUrl} alt="Error" />
    <div className="playlist-item__details">
      <div className="playlist-item__title">{track.title}</div>
      <div className="playlist-item__artist">{track.artist}</div>
    </div>
  </div>
  )
}