import { useState, useEffect } from "react"
import useAuth from "../Component_useAuth/useAuth" // Authentification
import SearchBar from "../Component_SearchBar/Searchbar" // Barred de recherche
import Player from "../Component_Player/Player" // Lecteur de musique
import TrackSearchResult from "../Component_TrackSearchResult/TrackSearchResult"  // Playlist
import Tendance from "../Component_Tendance/Tendance" // Tendance
import SelectCountry from "../Component_SelectCountry/SelectCountry" // Selecteur de Tendance
import SelectGenre from "../Component_SelectGenre/SelectGenre" // Selecteur de Tendance
import Genre from "../Component_Genre/Genre" // Genre
import { Container } from "react-bootstrap"
import SpotifyWebApi from "spotify-web-api-node"
import axios from "axios"
import Sidebar from "../Component_Sidebar/Sidebar"  // Menu à droite
import Home from "../Component_Home/Home" // Base de présentation
import AsItConcerns from "../Component_AsItConcerns/AsItConcerns" // A propos

import "./Dashboard.css"

const spotifyApi = new SpotifyWebApi({
  clientId: "d854a8b6e1754b23b1446366221d5165",
})

export default function Dashboard({ code }) {
  const accessToken = useAuth(code)
  const [search, setSearch] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [playingTrack, setPlayingTrack] = useState()
  const [lyrics, setLyrics] = useState("")

  const [countryCode, setCountryCode] = useState("");
  const [topTracks, setTopTracks] = useState([]);
  const [genreTracks, setGenreTracks] = useState([]);
  const [genreSelected, setGenreSelected] = useState("");

  
  console.log(searchResults)

  function chooseTrack(track) {
    setPlayingTrack(track)
    setSearch("")
    setLyrics("")
  }

  /* Vérifier si une piste est en cours de lecture et récupèrer les Lyrics à partir d'une API de paroles en appelant un endpoint "/lyrics". */
  useEffect(() => {
    if (!playingTrack) return

    axios
      .get("http://localhost:3001/lyrics", {
        params: {
          track: playingTrack.title,
          artist: playingTrack.artist,
        },
      })
      .then(res => {
        setLyrics(res.data.lyrics)
      })
  }, [playingTrack])

  /* Mise à jour de l'instance de SpotifyWebApi avec le accessToken lorsque celui-ci change. */
  useEffect(() => {
    if (!accessToken) return
    spotifyApi.setAccessToken(accessToken)
  }, [accessToken])

  /* Mise à jour des résultats de recherche chaque fois que l'utilisateur entre une nouvelle requête de recherche. 
  Il utilise l'instance de SpotifyWebApi pour appeler la méthode "searchTracks" qui renvoie les résultats de recherche sous forme d'objet JSON.
  Il extrait ensuite les informations pertinentes de chaque piste, notamment l'artiste, le titre, l'URI et l'URL de l'album. */
  useEffect(() => {
    if (!search) return setSearchResults([])
    if (!accessToken) return

    let cancel = false
    spotifyApi.searchTracks(search).then(res => {
      console.log(res)
      if (cancel) return
      setSearchResults(
        res.body.tracks.items.map(track => {
          const smallestAlbumImage = track.album.images.reduce(
            (smallest, image) => {
              if (image.height < smallest.height) return image
              return smallest
            },
            track.album.images[0]
          )

          return {
            artist: track.artists[0].name,
            title: track.name,
            uri: track.uri,
            albumUrl: smallestAlbumImage.url,
          }
        })
      )
    })

    return () => (cancel = true)
  }, [search, accessToken])

  /* Mise à jour des résultats de recherche chaque fois que l'utilisateur choisi un pays. 
  Il utilise l'instance de SpotifyWebApi pour appeler la méthode "getPlaylist" qui renvoie les résultats de recherche sous forme d'objet JSON en fonction du pays et de la date présente.
  Il extrait ensuite les informations pertinentes de chaque piste, notamment l'artiste, le titre, l'URI et l'URL de l'album. */

  useEffect(() => {
    if (!accessToken) return;
    if (!countryCode) {
      setTopTracks([]);
      return;
    }

    const timestamp = Date.now();

    spotifyApi
      .getPlaylist("37i9dQZEVXbMDoHDwVN2tF", {
        country: countryCode,
        timestamp: timestamp,
      })
      .then((res) => {
        setTopTracks(
          res.body.tracks.items.map((track) => {
            const smallestAlbumImage = track.track.album.images.reduce(
              (smallest, image) => {
                if (image.height < smallest.height) return image;
                return smallest;
              },
              track.track.album.images[0]
            );

            return {
              artist: track.track.artists[0].name,
              title: track.track.name,
              uri: track.track.uri,
              albumUrl: smallestAlbumImage.url,
            };
          })
        );
      });
  }, [accessToken, countryCode]);

  /* Mise à jour des résultats de recherche chaque fois que l'utilisateur choisi un genre. */

  useEffect(() => {
    if (!genreSelected || !accessToken) return;

    let cancel = false;
    spotifyApi.getPlaylistsForCategory(genreSelected, { limit: 1 }).then((res) => {
      const playlistId = res.body.playlists.items[0].id;
      spotifyApi.getPlaylistTracks(playlistId).then((res) => {
        if (cancel) return;
        setGenreTracks(
          res.body.tracks.items.map(track => {
            const smallestAlbumImage = track.album.images.reduce(
              (smallest, image) => {
                if (image.height < smallest.height) return image
                return smallest
              },
              track.album.images[0]
            )
          
            return {
              artist: track.artists[0].name,
              title: track.name,
              uri: track.uri,
              albumUrl: smallestAlbumImage ? smallestAlbumImage.url : '',
            }
          })
        );
      });
    });

    return () => (cancel = true);
  }, [accessToken, genreSelected]);

  /* ----------------------------------------------------------- */
  const [activeTab, setActiveTab] = useState(1);

  const handleTabClick = (tabIndex) => {
    setActiveTab(tabIndex);
  };

  /* Fonction pour se déconnecter */

  const handleLogout = (accessToken) => {
    accessToken = null;
  };
  

  /* Formulaire de recherche qui utilise l'état local "search" pour afficher les résultats de recherche pertinents en temps réel.
  Le composant "TrackSearchResult" est utilisé pour afficher chaque piste dans la liste de recherche. 
  Lorsqu'un utilisateur sélectionne une piste, la fonction "chooseTrack" est appelée pour définir la piste en cours de lecture.
  */
  return (
    <Container className="d-flex flex-column py-2" style={{ height: "100vh" }}>
      <Sidebar handleTabClick={handleTabClick} />
      
      <div className="flex-grow-1 my-2" id="section1" style={{ overflowY: "auto", display: activeTab === 1 ? "block" : "none" }}>
        <Home/>
      </div>

      <div className="flex-grow-1 my-2" id="section2" style={{ overflowY: "auto", display: activeTab === 2 ? "block" : "none" }}>
        <SearchBar search={search} setSearch={setSearch} />
        {searchResults.map(track => (
          <TrackSearchResult track={track} key={track.uri} chooseTrack={chooseTrack} />
        ))}
        {searchResults.length === 0 && (
          <div className="text-center" style={{ whiteSpace: "pre", color:"#fff" , margin:"2%"}}>
            {lyrics}
          </div>
        )}
      </div>

      <div className="flex-grow-1 my-2" id="section3" style={{ overflowY: "auto", display: activeTab === 3 ? "block" : "none" }}>
        <SelectCountry countryCode={countryCode} setCountryCode={setCountryCode} />
        <div>
        {topTracks.map((track) => (
          <Tendance key={track.uri} topTracks={track} chooseTrack={chooseTrack}/>
        ))}
        
      </div>
      </div>

      <div className="flex-grow-1 my-2" id="section4" style={{ overflowY: "auto", display: activeTab === 4 ? "block" : "none" }}>
        <SelectGenre genreSelected={genreSelected} setGenreSelected={setGenreSelected} />
        <div>
        {genreTracks.map((track) => (
          <Genre key={track.uri} genreTracks={track} chooseTrack={chooseTrack}/>
        ))}
      </div>
      </div>

      <div className="flex-grow-1 my-2" id="section5" style={{ overflowY: "auto", display: activeTab === 5 ? "block" : "none" }}>
          <AsItConcerns/>
      </div>

      <div className="flex-grow-1 my-2" id="section6" style={{ overflowY: "auto", display: activeTab === 6 ? "block" : "none" }}>
        <h1 className="sure">Are you sure to leave your best friend? ಥ﹏ಥ</h1>
        <button className="deconnection" onClick={handleLogout}>Disconnect Unfazed-SoundTrack</button>
      </div>

      <div>
        <Player accessToken={accessToken} trackUri={playingTrack?.uri} />
      </div>
    </Container>
  )
}
