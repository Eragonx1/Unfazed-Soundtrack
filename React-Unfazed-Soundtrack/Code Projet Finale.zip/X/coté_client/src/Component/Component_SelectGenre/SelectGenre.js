import React from "react";
import { Form } from "react-bootstrap";
import "../Component_SelectCountry/SelectCountry.css";

export default function SelectGenre(props) {
  const { genreSelected, setGenreSelected } = props;

  return (
    <div>
      <h1>Choose your musical style</h1>
      <Form.Select value={genreSelected} onChange={(f) => setGenreSelected(f.target.value)}>
          <option value="">Select a genre</option>
          <option value="pop">Pop</option>
          <option value="rock">Rock</option>
          <option value="hiphop">Hiphop</option>
          <option value="electronic">Electronic</option>
          <option value="indie">Indie</option>
          <option value="alternative">Alternative</option>
          <option value="rnb">Rnb</option>
          <option value="jazz">Jazz</option>
          <option value="country">Country</option>
          <option value="classical">Classical</option>
          <option value="blues">Blues</option>
          <option value="reggae">Reggae</option>
          <option value="folk">Folk</option>
          <option value="soul">Soul</option>
          <option value="funk">Funk</option>
          <option value="metal">Metal</option>
          <option value="punk">Punk</option>
          <option value="world">World</option>
          <option value="latin">Latin</option>
      </Form.Select>
    </div>
    
  );
}
