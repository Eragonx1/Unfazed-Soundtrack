import React from "react";
import "./AsItConcerns.css"

export default function AsItConcerns() {

    return (
        <div class="about">
        <h2>About Us</h2>
        <p>We are a group of 3rd year students in computer science license at Le Mans University in France and this project aims to
         validate 2 modules under the responsibility of Mrs. Valerie Renault which are: "IHM" and "Application WEB". 
         This project consists in using the Spotify API in order to extract enough information to meet the needs of the users that we had imposed
         on ourselves beforehand.</p>
         <p>The authors are : Mohamed AL AFTAN - Lucas AGAESSE - Dorian FRANCOIS</p>
         
        <form action="mailto:contact@example.com" method="post" enctype="text/plain">
            <div>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required/>
            </div>
            <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required/>
            </div>
            <div>
            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>
            </div>
            <button type="submit">Send</button>
        </form>
        </div>

    );
}
