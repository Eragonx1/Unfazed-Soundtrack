import React from "react";
import { Form } from "react-bootstrap";
import "./Searchbar.css";

export default function SearchBar({ search, setSearch }) {
  return (
    <div>
      <h1>Unfazed Browser</h1>
      <Form.Control
        className="barreRecherche"
        type="search"
        placeholder="Search Songs/Artists"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
    </div>
  );
}


