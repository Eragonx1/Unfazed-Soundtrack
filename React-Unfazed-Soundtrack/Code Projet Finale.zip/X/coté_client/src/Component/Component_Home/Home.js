import React from "react";
import logoPrincipale from "../../Img/Logo.png"
import "./Home.css"

export default function Home() {
  return (
    <div className="Base">
        <h1>Welcome to UNFAZED-SOUNDTRACK</h1>
        <img className="Main" src={logoPrincipale} alt="Unfazed-Soundtrack" />
        <p>The perfect companion for your musical journey. With our app, you can browse and discover a vast library of songs from your favorite artists and genres. Listen to curated playlists created by our music experts. Our app also offers a variety of features such as lyrics. Whether you're looking for the latest hits or rediscovering classic tunes, our music app has got you covered.</p>
    </div>
  );
}
