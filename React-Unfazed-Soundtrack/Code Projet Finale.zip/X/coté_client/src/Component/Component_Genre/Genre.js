import React from "react";

export default function Genre({ genre , chooseTrack}) {

  function handlePlay() {
      chooseTrack(genre)
  }

  return (
    <div
      className="d-flex m-2 align-items-center"
      style={{ cursor: "pointer" }}
      onClick={handlePlay}
    >
      <img src={genre.albumUrl} alt="Error" style={{ height: "64px", width: "64px" } } />
      <div className="ml-3">
        <div>{genre.title}</div>
        <div className="text-muted">{genre.artist}</div>
      </div>
    </div>
  );
}
