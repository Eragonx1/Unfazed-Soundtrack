import React, { useState } from "react";
import "./Sidebar.css";

//import bulle from "../../Img/bulle.png"
import deconnection from "../../Img/deconnection.png"
import discuter from "../../Img/discuter.png"
import disque from "../../Img/disque.png"
import logo from "../../Img/home.png"
import loupe from "../../Img/loupe.png"
import podium from "../../Img/podium.png"


export default function Sidebar({ handleTabClick }) {
  const [open, setOpen] = useState(false);

  const toggleSidebar = () => {
    setOpen(!open);
  };

  return (
    <div className={`sidebar ${open ? "open" : ""}`}>
      <button className="toggle-btn" onClick={toggleSidebar}>
        ☰
      </button>
      <ul>
        
        <li onClick={() => handleTabClick(1)}>
          <a href="#Section1"> <img className="imgMenuPrincipale" src={logo} alt="Unfazed-Soundtrack" />    Home</a>
        </li>
        <li onClick={() => handleTabClick(2)}>
          <a href="#Section2"> <img className="imgMenuPrincipale" src={loupe} alt="Recherche" />    Search</a>
        </li>
        <li onClick={() => handleTabClick(3)}>
          <a href="#Section3"> <img className="imgMenuPrincipale" src={podium} alt="Tendance" />    Country Trends</a>
        </li>
        <li onClick={() => handleTabClick(4)}>
          <a href="#Section4">  <img className="imgMenuPrincipale" src={disque} alt="Genre" />    Gender Trend</a>
        </li>
        <li onClick={() => handleTabClick(5)}>
          <a href="#Section5">  <img className="imgMenuPrincipale" src={discuter} alt="A propos" />    About Us</a>
        </li>
        <li className="bottom-element" onClick={() => handleTabClick(6)}>
          <a href="#Section6">  <img className="imgMenuPrincipale" src={deconnection} alt="A propos" />    Log out</a>
        </li>
      </ul>
    </div>
  );
};