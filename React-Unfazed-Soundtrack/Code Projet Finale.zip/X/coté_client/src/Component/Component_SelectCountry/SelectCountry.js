import React from "react";
import { Form } from "react-bootstrap";
import "./SelectCountry.css";

export default function SelectCountry(props) {
  const { countryCode, setCountryCode } = props;

  return (
    <div>
      <h1>Find the trends you want</h1>
      <Form.Select value={countryCode} onChange={(e) => setCountryCode(e.target.value)}>
        <option value="">Select a country</option>
        <option value="US">United States</option>
        <option value="GB">United Kingdom</option>
        <option value="FR">France</option>
        <option value="BR">Bresil</option>
        <option value="DE">Germany</option>
        <option value="IN">India</option>
        <option value="JP">Japan</option>
        <option value="MX">Mexico</option>
        <option value="ES">Spain</option>
        <option value="AU">Australia</option>
      </Form.Select>
    </div>
  );
}
